package com.cg.fms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.dto.Course;
import com.cg.fms.dto.Employee;
import com.cg.fms.dto.Feedback;
import com.cg.fms.dto.ParticipantEnrollment;
import com.cg.fms.dto.Training;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.CourseService;
import com.cg.fms.service.CourseServiceImpl;
import com.cg.fms.service.FeedbackService;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.ParticipantEnrollmentService;
import com.cg.fms.service.ParticipantEnrollmentServiceImpl;
import com.cg.fms.service.TrainingService;
import com.cg.fms.service.TrainingServiceImpl;

public class ParticipantHandler {
	Employee participant = null;
	CourseService courseService = null;
	ParticipantEnrollmentService partcipantEService = null;
	TrainingService trainingService = null;
	FeedbackService feedbackService = null;

	Scanner sc = new Scanner(System.in);

	public ParticipantHandler(Employee employee) {
		super();
		participant = employee;
		courseService = new CourseServiceImpl();
		partcipantEService = new ParticipantEnrollmentServiceImpl();
		trainingService = new TrainingServiceImpl();
		feedbackService = new FeedbackServiceImpl();
	}

	public void start() throws FMSException {

		System.out.println("*****************************************");
		System.out.println("Welcome " + participant.getEmployeeName());
		System.out.println("You are logged in as PARTICIPANT");
		// System.out.println("What do you want to do");

		ArrayList<ParticipantEnrollment> participantList = partcipantEService
				.getParticipantEnrollmentByParticipantId(participant.getEmployeeId());

		ArrayList<Training> trainingsAssigned = new ArrayList<>();

		for (ParticipantEnrollment enrollment : participantList) {
			trainingsAssigned.add(trainingService.getTrainingById(enrollment.getTrainingCode()));
		}

		ArrayList<Course> courseList = new ArrayList<>();

		for (Training training : trainingsAssigned) {
			courseList.add(courseService.getCourseById(training.getCourseCode()));
		}

		if (courseList.size() == 0) {
			System.out.println("Sorry! you are not enrolled with any course");
			System.out.println("Logging off....");
			return;
		}
		System.out.println("List of courses you are enrolled with : ");

		for (int i = 0; i < courseList.size(); i++) {
			System.out.println("Training Code : " + trainingsAssigned.get(i).getTrainingCode() + ", Name : "
					+ courseList.get(i).getCourseName());
		}
		while(true) {
			System.out.println("What do you want to do?");
			System.out.println("1.Add Feedback\n2.Logout");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Please enter the training code : ");
				int trainingCode = sc.nextInt();
				boolean available = false;
				for (Training training : trainingsAssigned) {
					if (training.getTrainingCode() == trainingCode) {
						available = true;
						break;
					}
				}
				if (available) {
					if (!alreadyGiven(trainingCode)) {
						Feedback feedback = takefeedback(trainingCode);

						int feedbackReceived = feedbackService.addFeedback(feedback);
						if (feedbackReceived == 1) {
							System.out.println("Thankyou for the feedback");
							break;
						} else {
							System.out.println("error in insertion, try again");
							continue;
						}
					} else {
						System.out.println("Alredy given feedback for this course");
					}
				} else {
					System.out.println("Wrong Training code entered, try again");
				}
				break;
				
			case 2:
				MainClass.main(null);
				
			default:
				break;
			}
		}
		
	

		// all menu items, switch case

	}

	private boolean alreadyGiven(int trainingCode) {
		// returns true if feedback is already given else false;

		try {
			Feedback fb = feedbackService.findFeedbackByPIdAndTCode(participant.getEmployeeId(), trainingCode);
			if (fb != null) {
				return true;
			}
		} catch (FMSException e) {
			System.out.println("Something Not Good");
		}

		return false;
	}

	public Feedback takefeedback(int trainingCode) throws FMSException {
		/*
		 * System.out.println("Enter training code : "); int trainingCode =
		 * sc.nextInt();
		 */
		/* System.out.println("Enter partcipant Id : "); */
		// int participantId = sc.nextInt();
		int participantId = participant.getEmployeeId();
		System.out.println("Rate the presentation and communication of trainer from 0 - 5 : ");
		int presentationCommunication = sc.nextInt();
		System.out.println("Rate the doubt clarification skill of trainer from 0 - 5 : ");
		int clarifyDoubts = sc.nextInt();
		System.out.println("Rate time management skill of trainer from 0 - 5 : ");
		int timeManagement = sc.nextInt();
		System.out.println("Rate the hand out solving skill of trainer from 0 - 5 : ");
		int handOut = sc.nextInt();
		System.out.println("Rate the harware and software network provided from 0 - 5 : ");
		int hwSwNetwork = sc.nextInt();
		sc.nextLine();
		System.out.println("Give additional comments if any : ");
		String comments = sc.nextLine();
		System.out.println("Give any suggestions : ");
		String suggestions = sc.nextLine();

		Feedback feedback = new Feedback(trainingCode, participantId, presentationCommunication, clarifyDoubts,
				timeManagement, handOut, hwSwNetwork, comments, suggestions);

		return feedback;
	}
}
