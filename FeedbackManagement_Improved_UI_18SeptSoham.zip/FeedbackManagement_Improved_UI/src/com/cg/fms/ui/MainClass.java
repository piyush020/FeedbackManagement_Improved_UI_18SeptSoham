package com.cg.fms.ui;

import java.util.Scanner;

import com.cg.fms.dao.EmployeeDao;
import com.cg.fms.dao.EmployeeDaoImpl;
import com.cg.fms.dto.Employee;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.EmployeeService;
import com.cg.fms.service.EmployeeServiceImpl;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EmployeeService employeeService = new EmployeeServiceImpl();

		System.out.println("****************FEEDBACK MANAGEMENT SYSTEM*************************");
		System.out.println("Press 1 for Login");
		System.out.println("Press 2 for Exit");

		Scanner sc = new Scanner(System.in);

		int choice = sc.nextInt();

		if (choice == 1) {
			while (true) {
				System.out.println("***********LOGIN*************");
				System.out.println("Please Enter Your Employee ID");
				int empId = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter password");
				String password = sc.nextLine();

				try {
					Employee employee = employeeService.getEmployeeById(empId);

					if (employee == null) {
						System.out.println("Employee not found with this Employee ID : " + empId);
						System.out.println("Please try again.....");
						continue;
					}
					if (!employee.getPassword().equals(password)) {
						System.out.println("Incorrect Password");
						System.out.println("Please try again.....");
						continue;
					}

					if (employee.getRole().equalsIgnoreCase("trainee")) {
						// TraineeHandler class object
						// start method

						ParticipantHandler handler = new ParticipantHandler(employee);
						handler.start();

					} else if (employee.getRole().equalsIgnoreCase("admin")) {
						// AdminHandler class object
						// start
						AdminHandler handler = new AdminHandler(employee);
						handler.start();
					} else if (employee.getRole().equalsIgnoreCase("coordinator")) {
						// CoordinatorHandler class object
						// start
						CoordinatorHandler handler = new CoordinatorHandler(employee);
						handler.start();
					} else {
						// rare scenario
						System.out.println("Role not found, exiting system .....");
						System.exit(0);
					}

				} catch (FMSException e) {
					e.printStackTrace();
					System.out.println("Something went wrong");
					System.out.println("Exiting system.....");
					System.exit(0);
				}
			}

		} else {
			System.exit(0);
		}

	}

}
