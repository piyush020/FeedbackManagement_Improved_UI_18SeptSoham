package com.cg.fms.dto;

public class Feedback {

	private int trainingCode;
	private int participantId;
	private int presentationCommunication;
	private int clarifyDoubts;
	private int timeManagement;
	private int handOut;
	private int hwSwNetwork;
	private String comments;
	private String suggestions;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public int getPresentationCommunication() {
		return presentationCommunication;
	}
	public void setPresentationCommunication(int presentationCommunication) {
		this.presentationCommunication = presentationCommunication;
	}
	public int getClarifyDoubts() {
		return clarifyDoubts;
	}
	public void setClarifyDoubts(int clarifyDoubts) {
		this.clarifyDoubts = clarifyDoubts;
	}
	public int getTimeManagement() {
		return timeManagement;
	}
	public void setTimeManagement(int timeManagement) {
		this.timeManagement = timeManagement;
	}
	public int getHandOut() {
		return handOut;
	}
	public void setHandOut(int handOut) {
		this.handOut = handOut;
	}
	public int getHwSwNetwork() {
		return hwSwNetwork;
	}
	public void setHwSwNetwork(int hwSwNetwork) {
		this.hwSwNetwork = hwSwNetwork;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
	public Feedback(int trainingCode, int participantId,
			int presentationCommunication, int clarifyDoubts,
			int timeManagement, int handOut, int hwSwNetwork, String comments,
			String suggestions) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
		this.presentationCommunication = presentationCommunication;
		this.clarifyDoubts = clarifyDoubts;
		this.timeManagement = timeManagement;
		this.handOut = handOut;
		this.hwSwNetwork = hwSwNetwork;
		this.comments = comments;
		this.suggestions = suggestions;
	}
	public Feedback() {
		super();
	}
	@Override
	public String toString() {
		return "Feedback [trainingCode=" + trainingCode + ", participantId="
				+ participantId + ", presentationCommunication="
				+ presentationCommunication + ", clarifyDoubts="
				+ clarifyDoubts + ", timeManagement=" + timeManagement
				+ ", handOut=" + handOut + ", hwSwNetwork=" + hwSwNetwork
				+ ", comments=" + comments + ", suggestions=" + suggestions
				+ "]";
	}

	
	
}
